//
//  ViewController.swift
//  SidearmAssessmentProject
//
//  Created by John Brackley on 4/22/22.
//

// Things I appreciated making:
// - I had a great time designing the UI from the colors to the animations, I used Georgia team colors because your team mentioned many of you were Georgia fans

// Things I had trouble with:
// - I noticed the inital project was built in SwiftUI, but I built this project in UIKit because that was what I was most comfortable with
// - I knew there was a simpler way to make one generic button and then create the three different buttons from that, because it was just three of them I manually created them
// -This pattern persisted throughout the making of the project especially when it came to creating the shadow openings that introduce each of the buttons, if I was able to make a single instance that served for all three I would not have had to manually write each of them the way that I did
// -Too much time spent on animations and the sequencing of them

import UIKit

class ViewController: UIViewController {
    
    var backgroundColorView = GradientView(frame: UIScreen.main.bounds)
    
    var promptLabel = UILabel()
    
    var sEntryPoint = UIView()
    var jEntryPoint = UIView()
    var kEntryPoint = UIView()
    
    var containerView = UIView()
    var swiftButton = UIButton()
    var javaButton = UIButton()
    var kotlinButton = UIButton()
    var resultsButton = UIButton()
    
    var swiftOpening = UIView()
    var javaOpening = UIView()
    var kotlinOpening = UIView()
    var resultsOpening = UIView()
    
    var currentVoteCount = 0
    var swiftCount = 0
    var javaCount = 0
    var kotlinCount = 0
    
    var swiftCountLabel = UILabel()
    var javaCountLabel = UILabel()
    var kotlinCountLabel = UILabel()
    
    var swiftResultsView = UITextView()
    
    var swiftDisplayCount = UITextView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        backgroundColorView.backgroundColor = .lightGray
//        backgroundColorView.image = UIImage(named: "backgroundOne.png")
        view.addSubview(backgroundColorView)
        
        promptLabel.text = "What is your favorite programming language?"
        promptLabel.font = UIFont.boldSystemFont(ofSize: 15)
        promptLabel.textColor = .white
        promptLabel.textAlignment = .center
        promptLabel.frame = CGRect(x: 0, y: backgroundColorView.bounds.height / 15.25, width: backgroundColorView.bounds.width, height: backgroundColorView.bounds.width / 9)
        view.addSubview(promptLabel)
        
        swiftCountLabel.text = "S \(swiftCount)"
        swiftCountLabel.font = UIFont.boldSystemFont(ofSize: 15)
        swiftCountLabel.textColor = .yellow
        swiftCountLabel.textAlignment = .center
        swiftCountLabel.frame = CGRect(x: containerView.bounds.width, y: containerView.bounds.height / 6.25, width: containerView.bounds.width, height: containerView.bounds.width / 9)
        
        javaCountLabel.text = "\(javaCount)"
        
        kotlinCountLabel.text = "\(kotlinCount)"
        
        containerView.frame = CGRect(x: backgroundColorView.bounds.width / 10, y: backgroundColorView.center.y, width: (backgroundColorView.bounds.width / 10) * 8, height: (backgroundColorView.bounds.width / 10) * 15)
        containerView.backgroundColor = .lightGray
        containerView.layer.cornerRadius = 9.0
        containerView.alpha = 0.0
//        view.addSubview(containerView)
        
        swiftButton.backgroundColor = .orange
        swiftButton.frame = CGRect(x: containerView.bounds.width / 4, y: (containerView.bounds.height / 5) + 50, width: (containerView.bounds.width / 4) * 3, height: containerView.bounds.width / 8)
        swiftButton.layer.cornerRadius = 9.0
        swiftButton.alpha = 0.0
        swiftButton.setTitle("Swift", for: .normal)
        swiftButton.setTitleColor(.black, for: .normal)
        swiftButton.addTarget(self, action: #selector(tappedSwiftButton), for: .touchUpInside)
        
        javaButton.backgroundColor = .red
        javaButton.frame = CGRect(x: containerView.bounds.width / 4, y: ((containerView.bounds.height / 5) * 2) + 50, width: (containerView.bounds.width / 4) * 3, height: containerView.bounds.width / 8)
        javaButton.layer.cornerRadius = 9.0
        javaButton.alpha = 0.0
        javaButton.setTitle("Java", for: .normal)
        javaButton.setTitleColor(.black, for: .normal)
        javaButton.addTarget(self, action: #selector(tappedJavaButton), for: .touchUpInside)
        view.addSubview(javaButton)
        
        kotlinButton.backgroundColor = .yellow
        kotlinButton.frame = CGRect(x: containerView.bounds.width / 4, y: ((containerView.bounds.height / 5) * 3) + 50, width: (containerView.bounds.width / 4) * 3, height: containerView.bounds.width / 8)
        kotlinButton.layer.cornerRadius = 9.0
        kotlinButton.alpha = 0.0
        kotlinButton.setTitle("Kotlin", for: .normal)
        kotlinButton.setTitleColor(.black, for: .normal)
        kotlinButton.addTarget(self, action: #selector(tappedKotlinButton), for: .touchUpInside)
        view.addSubview(kotlinButton)
        
        resultsButton.backgroundColor = .black
        resultsButton.frame = CGRect(x: containerView.bounds.width / 4, y: ((containerView.bounds.height / 5) * 4) + 50, width: (containerView.bounds.width / 4) * 3, height: containerView.bounds.width / 8)
        resultsButton.layer.cornerRadius = 9.0
        resultsButton.setTitle("View Results", for: .normal)
        resultsButton.addTarget(self, action: #selector(tappedResultsButton), for: .touchUpInside)
        view.addSubview(resultsButton)
        
        swiftOpening.frame = CGRect(x: (view.bounds.width / 2) - (swiftButton.bounds.width / 10), y: swiftButton.center.y, width: view.bounds.width / 10, height: view.bounds.width / 10)
        swiftOpening.layer.cornerRadius = 9.0
        swiftOpening.backgroundColor = .black
        swiftOpening.alpha = 0.0
        view.addSubview(swiftOpening)
        
        javaOpening.frame = CGRect(x: (view.bounds.width / 2) - (javaButton.bounds.width / 10), y: javaButton.center.y, width: view.bounds.width / 10, height: view.bounds.width / 10)
        javaOpening.layer.cornerRadius = 9.0
        javaOpening.backgroundColor = .black
        javaOpening.alpha = 0.0
        view.addSubview(javaOpening)
        
        kotlinOpening.frame = CGRect(x: (view.bounds.width / 2) - (kotlinButton.bounds.width / 10), y: kotlinButton.center.y, width: view.bounds.width / 10, height: view.bounds.width / 10)
        kotlinOpening.layer.cornerRadius = 9.0
        kotlinOpening.backgroundColor = .black
        kotlinOpening.alpha = 0.0
        view.addSubview(kotlinOpening)
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        UIView.animate(withDuration: 2.0, delay: 1.0, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.0,  animations: {
//            self.buttonContainerView.center.y -= 750.0
            self.swiftOpening.transform = CGAffineTransform(scaleX: 8, y: 1)
            self.swiftOpening.alpha = 0.5
            self.javaOpening.transform = CGAffineTransform(scaleX: 8, y: 1)
            self.javaOpening.alpha = 0.5
            self.kotlinOpening.transform = CGAffineTransform(scaleX: 8, y: 1)
            self.kotlinOpening.alpha = 0.5
            self.containerView.alpha = 1.0
            }, completion: {_ in
                self.addSwiftButton()
                self.addJavaButton()
                self.addKotlinButton()
        })
    }
    
    func addSwiftButton(){
        UIView.animate(withDuration: 2.5, delay: 0.0, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.0, options: [], animations: {
            self.view.addSubview(self.swiftButton)
            self.swiftButton.alpha = 1.0
            self.swiftButton.center.y -= 10
            self.swiftOpening.transform = CGAffineTransform(scaleX: -10, y: 1)
            self.swiftOpening.alpha = 0.0
        }, completion: nil)
    }
    
    func addJavaButton(){
        UIView.animate(withDuration: 2.5, delay: 0.1, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.0, options: [], animations: {
            self.javaButton.alpha = 1.0
            self.javaButton.center.y -= 10
            self.javaOpening.transform = CGAffineTransform(scaleX: -10, y: 1)
            self.javaOpening.alpha = 0.0
        }, completion: nil)
    }
    
    func addKotlinButton(){
        UIView.animate(withDuration: 2.5, delay: 0.2, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.0, options: [], animations: {
            self.kotlinButton.alpha = 1.0
            self.kotlinButton.center.y -= 10
            self.kotlinOpening.transform = CGAffineTransform(scaleX: -10, y: 1)
            self.kotlinOpening.alpha = 0.0
        }, completion: nil)
    }
    
    func showResults(){
        UIView.animate(withDuration: 5.5, delay: 0.0, usingSpringWithDamping: 0, initialSpringVelocity: 0, options: [], animations: {
        }, completion: {_ in
            self.displayResults()
        })
        UIView.transition(with: resultsButton, duration: 1.0, options: .transitionFlipFromBottom, animations: {
            self.resultsButton.setTitle("Thank You!", for: .normal)
            self.resultsButton.setTitleColor(.black, for: .normal)
            self.resultsButton.backgroundColor = .white
            self.resultsButton.isUserInteractionEnabled = false
        }, completion:{_ in
            self.flipSwiftButton()
            self.flipJavaButton()
            self.flipKotlinButton()
        })
    }
    
    @objc func tappedSwiftButton(){
        swiftCount += 1
        currentVoteCount += 1
        print("Swift score \(swiftCount)")
        swiftButton.isHighlighted = true
    }
    
    @objc func tappedKotlinButton(){
        kotlinCount += 1
        currentVoteCount += 1
        print("Kotlin count \(kotlinCount)")
        kotlinButton.isHighlighted = true
    }
    
    @objc func tappedJavaButton(){
        javaCount += 1
        currentVoteCount += 1
        print("Java count \(javaCount)")
        javaButton.isHighlighted = true
    }
    
    @objc func tappedResultsButton(){
        self.showResults()
        print("Results presented")
    }
    
    @objc func flipSwiftButton(){
        UIView.transition(with: swiftButton, duration: 0.7, options: .transitionFlipFromTop, animations: {
            self.swiftButton.setTitle("Swift \(self.swiftCount)", for: .normal)
        }, completion: nil)
    }
    
    @objc func flipJavaButton(){
        UIView.transition(with: javaButton, duration: 0.6, options: .transitionFlipFromTop, animations: {
            self.javaButton.setTitle("Java \(self.javaCount)", for: .normal)
        }, completion: nil)
    }
    
    @objc func flipKotlinButton(){
        UIView.transition(with: kotlinButton, duration: 0.5, options: .transitionFlipFromTop, animations: {
            self.kotlinButton.setTitle("Kotlin \(self.kotlinCount)", for: .normal)
        }, completion: nil)
    }
    
    func displayResults(){
        UIView.animate(withDuration: 2.5, delay: 0.0, usingSpringWithDamping: 0.0, initialSpringVelocity: 0.0, options: [], animations: {
            self.swiftButton.transform = CGAffineTransform(scaleX: 1, y: 1)
            self.javaButton.transform = CGAffineTransform(scaleX: 1, y: 1)
            self.kotlinButton.transform = CGAffineTransform(scaleX: 1, y: 1)
        }, completion: nil)
    }
    
//    func generateSelectableButton(x: Float, y: Float) -> UIButton {
//        var newButton = UIButton()
//        newButton.backgroundColor = .darkGray
//        newButton.frame = CGRect(x: CGFloat(x), y: CGFloat(y), width: backgroundColorView.bounds.width / 3, height: backgroundColorView.bounds.width / 9)
//        newButton.layer.cornerRadius = 9.0
//        return newButton
//    }
// General attempt to create the three buttons from one generic one
}


