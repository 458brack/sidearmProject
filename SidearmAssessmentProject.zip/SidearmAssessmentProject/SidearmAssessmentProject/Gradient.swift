//
//  Gradient.swift
//  SidearmAssessmentProject
//
//  Created by John Brackley on 4/22/22.
//

import Foundation
import UIKit

class GradientView: UIView {
    var startColor = UIColor.black
    var endColor = UIColor.red
    override func draw(_ rect: CGRect) {
        _ = rect.width
        _ = rect.height
        let path1 = UIBezierPath(roundedRect: rect, byRoundingCorners: UIRectCorner.allCorners, cornerRadii: CGSize(width: 8.0, height: 8.0))
        path1.addClip()
        let context = UIGraphicsGetCurrentContext()
        let colorChoices = [startColor.cgColor, endColor.cgColor]
        let colorSpace = CGColorSpaceCreateDeviceRGB()
        let colorLocations : [CGFloat] = [0.0, 1.0]
        let colorGradient = CGGradient(colorsSpace: colorSpace, colors: colorChoices as CFArray, locations: colorLocations)
        let startPoint = CGPoint.zero
        let endPoint = CGPoint(x: 0, y: self.bounds.height)
        context!.drawLinearGradient(colorGradient!, start: startPoint, end: endPoint, options: CGGradientDrawingOptions(rawValue: UInt32(0)))
    }
}
